import os
p = os.path.abspath(os.getcwd())
p2 = os.path.dirname(os.getcwd())
p3 = os.getcwd()
print("p1: ", p)
print("p2: ", p2)
print("p3: ", p3)
